import sqlalchemy as sa
import sqlalchemy.orm as orm
from sqlalchemy.orm import Session
import sqlalchemy.ext.declarative as dec
from sqlalchemy.exc import OperationalError
from loguru import logger
from time import sleep


SqlAlchemyBase = dec.declarative_base()

__factory = None


def global_init(database_config: dict or str):
    """
        Подключиться в базе данных и создать несуществующие таблицы.

        database_config : dict or str
            str style:
                'sqlite:///path/to/db.sqlite'
            dict style:
            {
                'drivername': 'postgresql+psycopg2',
                'host': 'localhost',
                'port': '5432',
                'username': 'db_user',
                'password': 'secret_password',
                'database': 'db_name'
            }
    """
    global __factory

    if __factory:
        return

    if isinstance(database_config, dict):
        conn_url = sa.engine.url.URL(**database_config)
    elif isinstance(database_config, str):
        conn_url = database_config
    else:
        raise TypeError('database config must be dict or str')

    logger.info(f"CONNECT TO {conn_url}")
    engine = sa.create_engine(conn_url, echo=False)
    __factory = orm.sessionmaker(bind=engine)

    while True:
        try:
            SqlAlchemyBase.metadata.create_all(engine)
        except OperationalError:
            sleep(5)
            logger.warning(f"ERROR! TRY TO RECONNECT")
        except KeyboardInterrupt or SystemExit as e:
            logger.info(f'Exit with {e.__class__.__name__}')
            break
        except Exception as e:
            logger.exception(e)
        else:
            logger.info(f"SUCCESS CONNECT")
            break


def create_session() -> Session:
    global __factory
    return __factory()
