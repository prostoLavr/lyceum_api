from . import db_session
from sqlalchemy.orm import Session
from typing import Optional, Iterable, Callable


need_to_close = bool


def __parse_db_sess(*args, **kwargs) -> tuple[Optional[Session], need_to_close, tuple, dict]:
    if args and isinstance(args[0], Session):
        return args[0], False, args[1:], kwargs
    elif 'db_sess' in kwargs.keys() and isinstance(kwargs['db_sess'], Session):
        return kwargs.pop('db_sess'), False, args, kwargs
    return db_session.create_session(), True, args, kwargs


def edit_func(func: Callable) -> Callable:
    """
        Декоратор, для функций изменения объектов
        и функций со сложным добавлением или удалением объектов.
    """

    def new_func(*args, **kwargs):
        db_sess, do_need_be_close, args, kwargs = __parse_db_sess(*args, **kwargs)
        value = func(db_sess, *args, **kwargs)
        if do_need_be_close:
            db_sess.commit()
            db_sess.close()
        else:
            db_sess.flush()
        return value

    return new_func


def add_func(func: Callable) -> Callable:
    """
        Декоратор для функций добавления новых объектов в базу данных.
        Добавляет в базу данных то, что вернула функция.
    """

    def new_func(*args, **kwargs):
        do_need_be_update = True
        db_sess, do_need_be_close, args, kwargs = __parse_db_sess(*args, **kwargs)
        value = func(db_sess, *args, **kwargs)
        if isinstance(value, Iterable):
            db_sess.add_all(value)
        elif value is not None:
            db_sess.add(value)
        else:
            do_need_be_update = False

        if do_need_be_close and do_need_be_update:
            db_sess.commit()
        elif do_need_be_update:
            db_sess.flush()

        if do_need_be_close:
            db_sess.close()

        return value

    return new_func


def remove_func(func: Callable) -> Callable:
    """
        Декоратор для функций удаления объектов из базы данных.
        Удаляет из базы данных объекты, которые вернёт функция.
    """

    def new_func(*args, **kwargs):
        db_sess, do_need_be_close, args, kwargs = __parse_db_sess(*args, **kwargs)
        value = func(db_sess, *args, **kwargs)
        db_sess.delete(value)
        if do_need_be_close:
            db_sess.commit()
            db_sess.close()
        else:
            db_sess.flush()
        return value

    return new_func


def search_func(func):
    """
       Декоратор, функций для поиска, в бд ничего не сохраняет.
    """

    def new_func(*args, **kwargs):
        db_sess, do_need_be_close, args, kwargs = __parse_db_sess(*args, **kwargs)
        value = func(db_sess, *args, **kwargs)
        if do_need_be_close:
            db_sess.close()
        return value

    return new_func
